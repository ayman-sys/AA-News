<?php
//Database Server Name:
DEFINE('DBHost','localhost');

//Database Username:
DEFINE('DBUser', 'root');

//Database Password:
DEFINE('DBPass','root');

//Database Name:
DEFINE('DBName','aurangabadtak');

//Character set:
DEFINE('DBCharset','utf8mb4');

//Database Collation:
DEFINE('DBCollation', 'utf8_general_ci');

//Database Prefix:
DEFINE('DBPrefix', '');
?>
